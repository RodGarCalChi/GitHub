import java.io.*;
import java.util.*;

public class DataLoader {

    public static List<Node> loadPedidos(String directory) {
        List<Node> pedidos = new ArrayList<>();
        File folder = new File(directory);
        File[] files = folder.listFiles((dir, name) -> name.startsWith("ventas") && name.endsWith(".txt"));
        int id = 1;

        if (files != null) {
            for (File file : files) {
                try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (line.trim().isEmpty()) continue;
                        String[] parts = line.split(":");
                        String[] rest = parts[1].split(",");
                        int x = Integer.parseInt(rest[0].trim());
                        int y = Integer.parseInt(rest[1].trim());
                        String volumenStr = rest[3].trim().replace("m3", "");
                        int volumen = Integer.parseInt(volumenStr);
                        String horasStr = rest[4].trim().replace("h", "");
                        int ventana = Integer.parseInt(horasStr);

                        pedidos.add(new Node(id++, "cliente", x, y, 0, ventana));
                    }
                } catch (Exception e) {
                    System.err.println("Error leyendo archivo de pedidos: " + file.getName());
                }
            }
        }
        return pedidos;
    }

    public static Set<String> loadBloqueos(String directory) {
        Set<String> bloqueados = new HashSet<>();
        File folder = new File(directory);
        File[] files = folder.listFiles((dir, name) -> name.endsWith(".txt"));

        if (files != null) {
            for (File file : files) {
                try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (line.contains(":")) {
                            String[] parts = line.split(":");
                            if (parts.length > 1) {
                                String[] coords = parts[1].split(",");
                                for (int i = 0; i < coords.length - 1; i += 2) {
                                    String key = coords[i].trim() + "," + coords[i + 1].trim();
                                    bloqueados.add(key);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Error leyendo archivo de bloqueos: " + file.getName());
                }
            }
        }
        return bloqueados;
    }
}
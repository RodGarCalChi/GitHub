import java.util.*;

public class Main {
    public static void main(String[] args) {
        String pedidosDir = "C:\\Users\\RODRIGO\\Desktop\\ACOAlgortihm\\ACOAlgortihm\\src\\pedidos\\pedidos.20250419";   // reemplazar con ruta real si necesario
        String bloqueosDir = "C:\\Users\\RODRIGO\\Desktop\\ACOAlgortihm\\ACOAlgortihm\\src\\bloqueos\\bloqueos.20250419";

        Node almacen = new Node(0, "almacen", 0, 0, 0, 1000);
        List<Node> nodes = new ArrayList<>();
        nodes.add(almacen);
        nodes.addAll(DataLoader.loadPedidos(pedidosDir));

        Set<String> bloqueados = DataLoader.loadBloqueos(bloqueosDir);

        List<Vehicle> vehicles = List.of(new Vehicle(1, 100, 100, almacen));

        ACOPlanner planner = new ACOPlanner(nodes, vehicles, 10, 100, 1.0, 5.0, 0.1, 100) {

            protected boolean isBlocked(Node from, Node to) {
                return bloqueados.contains(from.getX() + "," + from.getY()) || bloqueados.contains(to.getX() + "," + to.getY());
            }
        };

        List<Node> bestPath = planner.run();

        if (bestPath != null && !bestPath.isEmpty()) {
            System.out.println("Ruta óptima encontrada:");
            for (Node n : bestPath) {
                System.out.printf(" - Nodo ID: %d (%s) en (%d, %d)%n", n.getId(), n.getType(), n.getX(), n.getY());
            }
        } else {
            System.out.println("No se encontró una ruta válida.");
        }
    }
}
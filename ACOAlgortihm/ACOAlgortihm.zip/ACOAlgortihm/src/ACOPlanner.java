import java.util.*;

public class ACOPlanner {
    private final List<Node> nodes;//Lista de nodos
    private final List<Vehicle> vehicles;//Lista de vehiculos disponibles
    private final double[][] pheromones;//Matriz de feromonas entre nodos

    //Parametros del algoritmo ACO
    private final int nAnts, iterations;
    private final double alpha, beta, rho, Q;

    //Constructor del planificador
    public ACOPlanner(List<Node> nodes, List<Vehicle> vehicles, int nAnts, int iterations, double alpha, double beta, double rho, double Q) {
        this.nodes = nodes;
        this.vehicles = vehicles;
        this.nAnts = nAnts;
        this.iterations = iterations;
        this.alpha = alpha;
        this.beta = beta;
        this.rho = rho;
        this.Q = Q;

        //Inicializacion de la matriz de feromonas con valor 1.0
        int n = nodes.size();
        pheromones = new double[n][n];
        for (int i = 0; i < n; i++) Arrays.fill(pheromones[i], 1.0);
    }

    /*
    Ejecuta el algoritmo ACO y devuelve la mejor ruta encontrada
    * */
    public List<Node> run() {
        List<Node> bestPath = null;
        double bestDistance = Double.MAX_VALUE;

        for (int iter = 0; iter < iterations; iter++) {
            List<Ant> ants = new ArrayList<>();

            //Inicializacion de las hrmigas con los vehiculos disponibles
            for (int i = 0; i < nAnts; i++) {
                ants.add(new Ant(vehicles.get(i % vehicles.size())));
            }
            //Cada hormiga construye su camino
            for (Ant ant : ants) {
                Node start = ant.getVehicle().getLocation();
                ant.visit(start);

                Set<Node> unvisited = new HashSet<>(nodes);
                unvisited.remove(start);

                while (!unvisited.isEmpty()) {
                    Node current = ant.getPath().get(ant.getPath().size() - 1);
                    Node next = selectNextNode(ant, current, unvisited);
                    if (next == null || !ant.visit(next)) break;
                    unvisited.remove(next);
                }
                //Actualizar la mejor solución si esta hormiga encontró una mejor
                if (ant.getTotalDistance() < bestDistance) {
                    bestDistance = ant.getTotalDistance();
                    bestPath = new ArrayList<>(ant.getPath());
                }
            }
            //Evaporar y reforzar feromonas en base a las rutas encontradas
            updatePheromones(ants);
        }

        return bestPath;
    }


    /*
    * Selecciona el siguiente nodo que una hormiga debe visitar con base en la probabilidad
    * */
    private Node selectNextNode(Ant ant, Node current, Set<Node> unvisited) {
        Map<Node, Double> probabilities = new HashMap<>();
        double sum = 0.0;

        for (Node candidate : unvisited) {
            if (!ant.getVehicle().canReach(candidate)) continue;

            double tau = pheromones[current.getId()][candidate.getId()]; //Feromona actual
            double eta = 1.0 / (current.distanceTo(candidate) + 1e-6); //Visibilidad heurística
            double prob = Math.pow(tau, alpha) * Math.pow(eta, beta); //Probabilidad combinada
            probabilities.put(candidate, prob);
            sum += prob;
        }

        if (probabilities.isEmpty()) return null;

        //Selección probabilística
        double rand = Math.random() * sum;
        double cumulative = 0.0;

        for (Map.Entry<Node, Double> entry : probabilities.entrySet()) {
            cumulative += entry.getValue();
            if (rand <= cumulative) return entry.getKey();
        }
        //Fallback si algo falta
        return probabilities.keySet().iterator().next(); // fallback
    }
    /*
    * Actualiza la matriz de feromonas en base a las rutas construidas por las hormigas
    *
    * */
    private void updatePheromones(List<Ant> ants) {
        int n = pheromones.length;
        //Evaporacion de feromónas
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                pheromones[i][j] *= (1 - rho);
        //Deposición de feromonas
        for (Ant ant : ants) {
            double contribution = Q / (ant.getTotalDistance() + 1e-6);
            List<Node> path = ant.getPath();
            for (int i = 0; i < path.size() - 1; i++) {
                int from = path.get(i).getId();
                int to = path.get(i + 1).getId();
                pheromones[from][to] += contribution;
            }
        }
    }
}

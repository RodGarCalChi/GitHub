public class Vehicle {
    //Identificddor único del vehiculo
    private final int id;

    //Capacidad máxima de carga del vehículo
    private final int capacity;

    //COmbustible actual
    private double fuel;

    //Nodo actual en el que se encuentra el vehiculo

    private Node location;

    //Contructor que inicializa un vehiculo con su id, capacidad, combustible y ubicacioon
    public Vehicle(int id, int capacity, double fuel, Node location) {
        this.id = id;
        this.capacity = capacity;
        this.fuel = fuel;
        this.location = location;
    }
    //Getters para acceder a los atributos del vehiculo

    public int getId() { return id; }
    public int getCapacity() { return capacity; }
    public double getFuel() { return fuel; }
    public Node getLocation() { return location; }

    //Verifica si el vehiculo puede llegar a un nodo destino con el combustible
    public boolean canReach(Node node) {
        return fuel >= location.distanceTo(node);
    }

    //Verifica el vehiculo a un nuevo nodo si tiene suficiente combustible
    //Actualiza la ubicacion y reduce el combustible usado
    public boolean moveTo(Node node) {
        double d = location.distanceTo(node);
        if (d <= fuel) {
            fuel -= d;
            location = node;
            return true;
        }
        return false;
    }
        //Reinicia el vehiculo a una ubicacion iicial con el tanque lleno
    public void reset(Node initialLocation, double maxFuel) {
        this.fuel = maxFuel;
        this.location = initialLocation;
    }
}

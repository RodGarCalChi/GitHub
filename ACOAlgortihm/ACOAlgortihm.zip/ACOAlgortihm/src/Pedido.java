public class Pedido {
    //Identificador único del pedido
    private final int id;
    //Coordenadas de ubicación del cliente que solícito el pedido
    private final int x, y;
    //Voluemn de GLP solicitado(en m3)
    private final int volumen;
    //Tiempo límite para que el pedido sea entregado
    private final int tiempoLimite;

    public Pedido(int id, int x, int y, int volumen, int tiempoLimite) {
        this.id = id;
        this.x = x;
        this.y = y;
        this.volumen = volumen;
        this.tiempoLimite = tiempoLimite;
    }
    //Métodos getter para acceder a los atributos del pedido
    public int getId() { return id; }
    public int getX() { return x; }
    public int getY() { return y; }
    public int getVolumen() { return volumen; }
    public int getTiempoLimite() { return tiempoLimite; }
}

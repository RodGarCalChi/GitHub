import java.util.*;

public class Ant {
    //Ruta construida para la hormiga (orden de nodos visitados)
    private final List<Node> path = new ArrayList<>();

    //Conjunto de nodos ya visitados, para evitar repeticiones
    private final Set<Integer> visited = new HashSet<>();

    //Distancia total recorrida por esta hormiga
    private double totalDistance = 0.0;

    //vehiulo que representa las capaidades y el estado actual
    private final Vehicle vehicle;

    /*Contructor que crea una copia del vehículo para esta hormiga.
    * Se copia para que cada hormiga tenga su estado de vehículo independiente
    * */
    public Ant(Vehicle vehicle) {
        this.vehicle = new Vehicle(vehicle.getId(), vehicle.getCapacity(), vehicle.getFuel(), vehicle.getLocation());
    }

    public boolean visit(Node node) {
        //Evita visitar nodos ya recorridos o que no son alcanzables
        if (visited.contains(node.getId()) || !vehicle.canReach(node)) return false;

        //Si ya hay un nodo anterior, se suma la distancia recorrida
        if (!path.isEmpty()) {
            totalDistance += path.get(path.size() - 1).distanceTo(node);
        }
        //Se agrega el nodo al camino y se actualia el estado del vehiculo
        path.add(node);
        visited.add(node.getId());
        vehicle.moveTo(node);
        return true;
    }
    /* Devuelve las distancia total recorrida por esta hormiga*/
    public List<Node> getPath() {
        return path;
    }
    /* Devuelve el estado actual del vehiculo asociado a esta hormiga*/
    public double getTotalDistance() {
        return totalDistance;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }
}

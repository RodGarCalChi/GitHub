public class Node {
    //Identificado único del nodo(almacén a cliente)
    private final int id;

    //Tipo del nodo:puede ser "almacen" o "cliente"
    private final String type; // "almacen" o "cliente"

    //Coordenadas X e Y en el mapa(para cálculo de distancias)
    private final int x, y;

    //Tiempo de inicio y fin de ventana de atención(ventan de tiempo)
    private final int windowStart, windowEnd;

    //Constructor que inicialia todos los campos del nodo
    public Node(int id, String type, int x, int y, int windowStart, int windowEnd) {
        this.id = id;
        this.type = type;
        this.x = x;
        this.y = y;
        this.windowStart = windowStart;
        this.windowEnd = windowEnd;
    }
    //Getters  para cada atributo
    public int getId() { return id; }
    public String getType() { return type; }
    public int getX() { return x; }
    public int getY() { return y; }
    public int getWindowStart() { return windowStart; }
    public int getWindowEnd() { return windowEnd; }

    //Método para calcualar la distancia euclideana entre este nodo y otro
    public double distanceTo(Node other) {
        return Math.hypot(this.x - other.x, this.y - other.y);
    }
    //Representacion del nodo, útil para debugging o impresión
    @Override
    public String toString() {
        return String.format("Node{id=%d, type=%s, (%d,%d), ventana=%d-%d}", id, type, x, y, windowStart, windowEnd);
    }
}
